public class Profile{
	public static void main( String[] args){
		System.out.println("Caren Hachem, mechatronics engineering, first year,hobby:drawing");
}
}