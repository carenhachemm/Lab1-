public class MyFirstProgram
{
public static void main(String[] args){
System.out.print("This is my ");
System.out.println("First java program");
System.out.println("Programming is fun!");
}
}