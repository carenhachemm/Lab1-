public class Problems {
	public static void main(String [] args){ 
		System.out.print("Hi,can we check this?");
		System.out.println("It has a lot of problems");
		System.out.print("Yeah, I know !!!");
		// This a comment ;
			}
}